package com.farhan.catatan;

/*
 * NIM : 101185054
 *Nama : Farhan Milardi
 *Kelas : IF-3
 *Email : farhan.10118054@mahasiswa.unikom.ac.id
 * */

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import androidx.fragment.app.DialogFragment;

import com.farhan.catatan.R;

public class DialogAbout extends DialogFragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.about,container,false);
    }
}
