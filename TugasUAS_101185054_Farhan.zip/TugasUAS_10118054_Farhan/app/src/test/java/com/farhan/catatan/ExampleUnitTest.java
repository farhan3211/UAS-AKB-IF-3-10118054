package com.farhan.catatan;

import org.junit.Test;

import static org.junit.Assert.*;
/*
 * NIM : 101185054
 *Nama : Farhan Milardi
 *Kelas : IF-3
 *Email : farhan.10118054@mahasiswa.unikom.ac.id
 * */
/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}